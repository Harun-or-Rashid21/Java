package pkgclass;

public class Class extends NewClass{
    
    
    void display(){
        System.out.println();
    
    }

    public static void main(String[] args) {
        
        NewClass ob = new NewClass();
        
        
        Class cd = new Class();
        cd.display();
        
        
        
        
        
    }
    
}
