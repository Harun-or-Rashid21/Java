package pkgclass;
 
public class NewClass{
    
    public int a = 100;
    private int b = 200;
    protected int c = 300;
    int d = 400;
    
    void sum(){
    int add;
    add = a+b+
    
    }
    
   
}

