
package demo;


public class Add {
    int a,b;
    
    void setData(){
    a = 10;
    b = 20;
    }
    
    void sum(){
    int add;
    add = a + b;
        System.out.println(add);
    }
    
    
}
