
package demo;


public class Demo1 {


    public static void main(String[] args) {
        Add ad = new Add();
        ad.setData();
        ad.sum();
        
    }
    
}
