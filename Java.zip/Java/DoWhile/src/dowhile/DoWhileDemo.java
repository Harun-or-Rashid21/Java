package dowhile;

public class DoWhileDemo {

	public static void main(String[] args) {
		int counter = 0;
		
		do{
			System.out.println("Counter :" +counter++);
		} while(counter < 5);
	}

}
