package lamp;


class Lamp {
 
    
    void turnOn(){
    
    isOn = true;
        System.out.println("Light On");
    }
    
    void turnOf(){
    isOn = false;
        System.out.println("Light Of");
    }
   boolean isOn; 
   
}



