package com.google;

/**
 * Hello World application
 * 
 * @author Harun_or_rashid
 *
 */

public class HelloWorld {
	/**
	 * To entry point
	 * 
	 * @param args input arguments
	 */

	public static void main(String[] args) {
		System.out.println("Hello World!");
	}

}
