
package main;


public class Add {
    
    //Create a Method
    public int addNumber(int a, int b){
        int sum;
       sum = a+b; 
        
    return sum;
    };
            
}
