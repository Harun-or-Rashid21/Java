package main;

import java.util.Scanner;

public class Main {

    
    public static void main(String[] args) {
        System.out.println("Please Enter Num1:");
        Scanner sc = new Scanner(System.in);
        int Num1 = sc.nextInt();
        System.out.println("Please Enter Num2:");
        int Num2 = sc.nextInt();
       
       
       Add ob = new Add();
       int result = ob.addNumber(Num1, Num2);
        System.out.println("Sum is: "+result);
    }
    
}
