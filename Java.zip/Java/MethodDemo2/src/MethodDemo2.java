
public class MethodDemo2 {

	
	public static void main(String[] args) {
		addition(5,6);
		addition(10,5);
		addition(7,7);
	}
	
	public static void addition(int a, int b) {
		System.out.println("Addition: "+(a+b));
	}
}
